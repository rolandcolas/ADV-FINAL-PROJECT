/*import firebase from "firebase/app";
import "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyCcgDuOo9CZSYbdKJcpLNgbJmuhb83xdpk",
  authDomain: "react-contact-4b516.firebaseapp.com",
  databaseURL: "https://react-contact-4b516-default-rtdb.firebaseio.com",
  projectId: "react-contact-4b516",
  storageBucket: "react-contact-4b516.appspot.com",
  messagingSenderId: "477171864956",
  appId: "1:477171864956:web:39c8685009722b74c5c0f9"
};

  const fireDb =  firebase.initializeApp(firebaseConfig);
  export default fireDb.database().ref(); */

  import firebase from "firebase/app";
import "firebase/auth";
import "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyCcgDuOo9CZSYbdKJcpLNgbJmuhb83xdpk",
  authDomain: "react-contact-4b516.firebaseapp.com",
  databaseURL: "https://react-contact-4b516-default-rtdb.firebaseio.com",
  projectId: "react-contact-4b516",
  storageBucket: "react-contact-4b516.appspot.com",
  messagingSenderId: "477171864956",
  appId: "1:477171864956:web:39c8685009722b74c5c0f9"
};

firebase.initializeApp(firebaseConfig);

const fireDb = firebase.database().ref();
export default fireDb;
