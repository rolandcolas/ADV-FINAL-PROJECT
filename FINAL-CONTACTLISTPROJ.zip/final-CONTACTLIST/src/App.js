// App.js


/*LAST LATEST

import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import "./App.css";
import Home from "./pages/Home";
import AddEdit from "./pages/AddEdit";
import View from "./pages/View";
import About from "./pages/About";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./components/Header";
import Register from "./pages/Register";
import Login from "./pages/Login";
import { AuthProvider } from './AuthContext'; // Import the AuthProvider

const App = () => {
  return (
    <BrowserRouter>
      <AuthProvider> {/* Wrap your app with AuthProvider }
        <div className="App app-background"> {/* Apply the background class here }
          <Header />
          {/* Main content }
          <Switch>
            <Route exact path="/register" component={Register} />
            <Route exact path="/" component={Login} />
            <Route exact path="/home" component={Home} />
            <Route path="/add" component={AddEdit} />
            <Route path="/update/:id" component={AddEdit} />
            <Route path="/view/:id" component={View} />
            <Route path="/about" component={About} />
          </Switch>
          <ToastContainer position="top-center" />
        </div>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;*/

import React from "react";
import { BrowserRouter, Switch, Route, useLocation } from "react-router-dom";
import "./App.css";
import Home from "./pages/Home";
import AddEdit from "./pages/AddEdit";
import View from "./pages/View";
import About from "./pages/About";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./components/Header";
import Register from "./pages/Register";
import Login from "./pages/Login";
import { AuthProvider } from './AuthContext';

const AppContent = () => {
  const location = useLocation();
  const noHeaderRoutes = ["/", "/register"];

  return (
    <div className="App app-background">
      {!noHeaderRoutes.includes(location.pathname) && <Header />}
      <Switch>
        <Route exact path="/register" component={Register} />
        <Route exact path="/" component={Login} />
        <Route exact path="/home" component={Home} />
        <Route path="/add" component={AddEdit} />
        <Route path="/update/:id" component={AddEdit} />
        <Route path="/view/:id" component={View} />
        <Route path="/about" component={About} />
      </Switch>
      <ToastContainer position="top-center" />
    </div>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </BrowserRouter>
  );
};
export default App;
