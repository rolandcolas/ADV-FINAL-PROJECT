/* AuthContext.js
import React, { createContext, useContext, useEffect, useState } from 'react';
import firebase from 'firebase/app';
import 'firebase/auth';

// Create a new context
const AuthContext = createContext();

// Provider component for AuthContext
export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);

  // Function to set current user based on Firebase Authentication state
  useEffect(() => {
    const unsubscribe = firebase.auth().onAuthStateChanged(user => {
      setCurrentUser(user);
    });
    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider value={{ currentUser }}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to use AuthContext
export function useAuth() {
  return useContext(AuthContext);
} */

import React, { createContext, useContext, useEffect, useState } from 'react';
import firebase from 'firebase/app';
import 'firebase/auth';

// Create a new context
const AuthContext = createContext();

// Provider component for AuthContext
export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);

  // Function to set current user based on Firebase Authentication state
  useEffect(() => {
    const unsubscribe = firebase.auth().onAuthStateChanged(user => {
      setCurrentUser(user);
    });
    return unsubscribe;
  }, []);

  // Function to handle user logout
  const logout = () => {
    return firebase.auth().signOut();
  };

  return (
    <AuthContext.Provider value={{ currentUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to use AuthContext
export function useAuth() {
  return useContext(AuthContext);
}

