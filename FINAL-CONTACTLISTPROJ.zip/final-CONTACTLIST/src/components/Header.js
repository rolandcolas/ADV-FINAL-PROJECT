/*import React from 'react';
import { Link, useHistory } from 'react-router-dom';
import { useAuth } from '../AuthContext'; // Import the AuthContext to access the current user and authentication methods
import './Header.css';

const Header = () => {
  const { currentUser, logout } = useAuth(); // Destructure the logout function from useAuth
  const history = useHistory();

  const handleLogout = async () => {
    try {
      if (logout) {
        await logout();
        history.push('/login'); // Redirect to login page after logout
      } else {
        console.error("Logout function not provided by AuthContext");
      }
    } catch (error) {
      console.error("Failed to logout:", error);
    }
  };

  return (
    <nav className="header-nav">
      <div className="logo">Contactlist</div>
      <ul className="nav-links">
        <li><Link to="/home">Home</Link></li>
        <li><Link to="/add">Add contact</Link></li>
        <li><Link to="/about">About us</Link></li>
        {currentUser && (
          <li>
            <button onClick={handleLogout} className="logout-button">Logout</button>
          </li>
        )}
      </ul>
    </nav>
  );
};

export default Header; */

import React from 'react';
import { Link, useHistory } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import './Header.css';

const Header = () => {
  const { currentUser, logout } = useAuth();
  const history = useHistory();

  const handleLogout = async () => {
    try {
      await logout();
      history.push('/'); // Redirect to login page after logout
    } catch (error) {
      console.error("Failed to logout:", error);
    }
  };

  return (
    <nav className="header-nav">
      <div className="logo">Contactlist</div>
      <ul className="nav-links">
        <li><Link to="/home">Home</Link></li>
        <li><Link to="/add">Add contact</Link></li>
        <li><Link to="/about">About us</Link></li>
        {currentUser && (
          <li>
            <button onClick={handleLogout} className="logout-button">Logout</button>
          </li>
        )}
      </ul>
    </nav>
  );
};

export default Header;
