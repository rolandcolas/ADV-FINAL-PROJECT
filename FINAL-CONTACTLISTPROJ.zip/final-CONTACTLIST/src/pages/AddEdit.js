/*import React, {useState, useEffect} from 'react';
import {useHistory, useParams} from "react-router-dom";
import "./AddEdit.css";
import fireDb from "../firebase";
import {toast} from "react-toastify";
import firebase from 'firebase/app';
import 'firebase/auth';

const initialState = {
    name: "",
    email: "",
    contact: ""
}
 
const AddEdit = () => {
    const [state, setState] =  useState(initialState);
    const [data, setData] = useState({});

    const {name, email, contact} =  state;
    const history = useHistory();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setState({ ...state, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name || !email || !contact) {
            alert('Please provide value in each input field');
        } else {
            // Get the current user's ID
            const userId = firebase.auth().currentUser.uid;
            
            // Add the user's ID to the contact object
            const contactData = { ...state, userId };
    
            // Push the contact data to the database
            fireDb.child('contacts').push(contactData, (err) => {
                if (err) {
                    alert(err.message);
                } else {
                    alert('Contact Added Successfully');
                    history.push('/home');
                }
            });
        }
    };
    
    
    return (
        <div style={{ marginTop: '100px' }}>
            <form
                style={{
                    margin: 'auto',
                    padding: '15px',
                    maxWidth: '400px',
                    alignContent: 'center'
                }}
                onSubmit={handleSubmit}
            >
                <label htmlFor="name">Name</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Your Name..."
                    value={name}
                    onChange={handleInputChange}
                />

                <label htmlFor="email">Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Your Email..."
                    value={email}
                    onChange={handleInputChange}
                />

                <label htmlFor="contact">Contact</label>
                <input
                    type="number"
                    id="contact"
                    name="contact"
                    placeholder="Your Contact No. ..."
                    value={contact}
                    onChange={handleInputChange}
                />

                <input type="submit" value="Save" />
            </form>
        </div>
    );
};

export default AddEdit; */

import React, { useState } from 'react';
import { useHistory } from "react-router-dom";
import "./AddEdit.css";
import fireDb from "../firebase";
import firebase from 'firebase/app';
import 'firebase/auth';

const initialState = {
    name: "",
    email: "",
    contact: ""
}

const AddEdit = () => {
    const [state, setState] = useState(initialState);
    const { name, email, contact } = state;
    const history = useHistory();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setState({ ...state, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name || !email || !contact) {
            alert('Please provide value in each input field');
        } else {
            const userId = firebase.auth().currentUser.uid;
            const contactData = { ...state, userId };
            fireDb.child('contacts').push(contactData, (err) => {
                if (err) {
                    alert(err.message);
                } else {
                    alert('Contact Added Successfully');
                    history.push('/home');
                }
            });
        }
    };

    const handleCancel = () => {
        history.push('/home');
    };

    return (
        <div style={{ marginTop: '100px' }}>
            <form onSubmit={handleSubmit}>
                <label htmlFor="name">Name</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Your Name..."
                    value={name}
                    onChange={handleInputChange}
                />

                <label htmlFor="email">Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Your Email..."
                    value={email}
                    onChange={handleInputChange}
                />

                <label htmlFor="contact">Contact</label>
                <input
                    type="number"
                    id="contact"
                    name="contact"
                    placeholder="Your Contact No. ..."
                    value={contact}
                    onChange={handleInputChange}
                />

                <div className="button-container">
                    <input type="submit" value="Save" />
                    <button type="button" onClick={handleCancel}>Cancel</button>
                </div>
            </form>
        </div>
    );
};

export default AddEdit;


