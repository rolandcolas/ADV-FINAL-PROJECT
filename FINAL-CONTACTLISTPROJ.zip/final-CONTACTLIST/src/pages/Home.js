// import React, { useState, useEffect } from 'react';
// import fireDb from "../firebase";

// const Home = () => {
//     const [contacts, setContacts] = useState([]);

//     useEffect(() => {
//         const contactsRef = fireDb.child('contacts');
//         contactsRef.on('value', (snapshot) => {
//             const contacts = snapshot.val();
//             const contactList = [];
//             for (let id in contacts) {
//                 contactList.push({ id, ...contacts[id] });
//             }
//             setContacts(contactList);
//         });
//         return () => contactsRef.off('value');
//     }, []);

//     return (
//         <div>
//             <h2>Contacts</h2>
//             <ul>
//                 {contacts.map(contact => (
//                     <li key={contact.id}>
//                         <strong>Name:</strong> {contact.name}, <strong>Email:</strong> {contact.email}, <strong>Contact:</strong> {contact.contact}
//                     </li>
//                 ))}
//             </ul>
//         </div>
//     );
// }

// export default Home;


// import React, { useState, useEffect } from 'react';
// import fireDb from "../firebase";
// import { useAuth } from "../AuthContext"; // Import AuthContext for accessing current user

// const Home = () => {
//     const { currentUser } = useAuth(); // Access current user from AuthContext
//     const [userContacts, setUserContacts] = useState([]);

//     useEffect(() => {
//         // Check if user is logged in before fetching contacts
//         if (currentUser) {
//             const contactsRef = fireDb.child('contacts').orderByChild('userId').equalTo(currentUser.uid);
//             contactsRef.on('value', (snapshot) => {
//                 const contacts = snapshot.val();
//                 const contactList = [];
//                 for (let id in contacts) {
//                     contactList.push({ id, ...contacts[id] });
//                 }
//                 setUserContacts(contactList);
//             });

//             return () => contactsRef.off('value');
//         }
//     }, [currentUser]);

//     // Function to delete a contact
//     const deleteContact = (id) => {
//         if (window.confirm('Are you sure you want to delete this contact?')) {
//             fireDb.child(`contacts/${id}`).remove()
//                 .then(() => {
//                     setUserContacts(prevContacts => prevContacts.filter(contact => contact.id !== id));
//                     console.log("Contact deleted successfully");
//                 })
//                 .catch(error => console.error("Error deleting contact:", error.message));
//         }
//     };

//     // Function to update a contact
//     const updateContact = (id, updatedContact) => {
//         fireDb.child(`contacts/${id}`).update(updatedContact)
//             .then(() => {
//                 setUserContacts(prevContacts => prevContacts.map(contact => {
//                     if (contact.id === id) {
//                         return { ...contact, ...updatedContact };
//                     }
//                     return contact;
//                 }));
//                 console.log("Contact updated successfully");
//             })
//             .catch(error => console.error("Error updating contact:", error.message));
//     };

//     return (
//         <div>
//             <h2>Contacts</h2>
//             <ul>
//                 {userContacts.map(contact => (
//                     <li key={contact.id}>
//                         <strong>Name:</strong> {contact.name}, <strong>Email:</strong> {contact.email}, <strong>Contact:</strong> {contact.contact}
//                         <button onClick={() => deleteContact(contact.id)}>Delete</button>
//                         <button onClick={() => updateContact(contact.id, { name: "Updated Name", email: "updated@email.com", contact: "1234567890" })}>Update</button>
//                     </li>
//                 ))}
//             </ul>
//         </div>
//     );
// }

// export default Home;

// import React, { useState, useEffect } from 'react';
// import fireDb from "../firebase";
// import { useAuth } from "../AuthContext"; // Import AuthContext for accessing current user
// import './Home.css'; // Import CSS file

// const Home = () => {
//     const { currentUser } = useAuth(); // Access current user from AuthContext
//     const [userContacts, setUserContacts] = useState([]);
//     const [editingContactId, setEditingContactId] = useState(null);
//     const [editedContact, setEditedContact] = useState({ name: "", email: "", contact: "" });

//     useEffect(() => {
//         // Check if user is logged in before fetching contacts
//         if (currentUser) {
//             const contactsRef = fireDb.child('contacts').orderByChild('userId').equalTo(currentUser.uid);
//             contactsRef.on('value', (snapshot) => {
//                 const contacts = snapshot.val();
//                 const contactList = [];
//                 for (let id in contacts) {
//                     contactList.push({ id, ...contacts[id] });
//                 }
//                 setUserContacts(contactList);
//             });

//             return () => contactsRef.off('value');
//         }
//     }, [currentUser]);

//     // Function to delete a contact
//     const deleteContact = (id) => {
//         if (window.confirm('Are you sure you want to delete this contact?')) {
//             fireDb.child(`contacts/${id}`).remove()
//                 .then(() => {
//                     setUserContacts(prevContacts => prevContacts.filter(contact => contact.id !== id));
//                     console.log("Contact deleted successfully");
//                 })
//                 .catch(error => console.error("Error deleting contact:", error.message));
//         }
//     };

//     // Function to enable editing mode for a contact
//     const enableEditingMode = (id, contact) => {
//         setEditingContactId(id);
//         setEditedContact(contact);
//     };

//     // Function to save changes after editing a contact
//     const saveChanges = () => {
//         fireDb.child(`contacts/${editingContactId}`).update(editedContact)
//             .then(() => {
//                 console.log("Contact updated successfully");
//                 setEditingContactId(null);
//             })
//             .catch(error => console.error("Error updating contact:", error.message));
//     };

//     return (
//         <div className="home-container">
//             <h2>Contacts</h2>
//             <ul className="contact-list">
//                 {userContacts.map(contact => (
//                     <li key={contact.id} className="contact-item">
//                         {editingContactId === contact.id ? (
//                             <div className="edit-mode">
//                                 <input type="text" value={editedContact.name} onChange={(e) => setEditedContact({ ...editedContact, name: e.target.value })} />
//                                 <input type="email" value={editedContact.email} onChange={(e) => setEditedContact({ ...editedContact, email: e.target.value })} />
//                                 <input type="text" value={editedContact.contact} onChange={(e) => setEditedContact({ ...editedContact, contact: e.target.value })} />
//                                 <button onClick={saveChanges}>Save</button>
//                             </div>
//                         ) : (
//                             <div>
//                                 <strong>Name:</strong> {contact.name}, <strong>Email:</strong> {contact.email}, <strong>Contact:</strong> {contact.contact}
//                                 <button onClick={() => deleteContact(contact.id)}>Delete</button>
//                                 <button onClick={() => enableEditingMode(contact.id, contact)}>Edit</button>
//                             </div>
//                         )}
//                     </li>
//                 ))}
//             </ul>
//         </div>
//     );
// }

// export default Home;




/*import React, { useState, useEffect } from 'react';
import fireDb from "../firebase";
import { useAuth } from "../AuthContext"; // Import AuthContext for accessing current user
import './Home.css'; // Import CSS file

const Home = () => {
    const { currentUser } = useAuth(); // Access current user from AuthContext
    const [userContacts, setUserContacts] = useState([]);
    const [editingContactId, setEditingContactId] = useState(null);
    const [editedContact, setEditedContact] = useState({ name: "", email: "", contact: "" });

    useEffect(() => {
        // Check if user is logged in before fetching contacts
        if (currentUser) {
            const contactsRef = fireDb.child('contacts').orderByChild('userId').equalTo(currentUser.uid);
            contactsRef.on('value', (snapshot) => {
                const contacts = snapshot.val();
                const contactList = [];
                for (let id in contacts) {
                    contactList.push({ id, ...contacts[id] });
                }
                setUserContacts(contactList);
            });

            return () => contactsRef.off('value');
        }
    }, [currentUser]);

    // Function to delete a contact
    const deleteContact = (id) => {
        if (window.confirm('Are you sure you want to delete this contact?')) {
            fireDb.child(`contacts/${id}`).remove()
                .then(() => {
                    setUserContacts(prevContacts => prevContacts.filter(contact => contact.id !== id));
                    console.log("Contact deleted successfully");
                })
                .catch(error => console.error("Error deleting contact:", error.message));
        }
    };

    // Function to enable editing mode for a contact
    const enableEditingMode = (id, contact) => {
        setEditingContactId(id);
        setEditedContact(contact);
    };

    // Function to save changes after editing a contact
    const saveChanges = () => {
        fireDb.child(`contacts/${editingContactId}`).update(editedContact)
            .then(() => {
                console.log("Contact updated successfully");
                setEditingContactId(null);
            })
            .catch(error => console.error("Error updating contact:", error.message));
    };

    return (
        <div className="home-container">
            <h2>Contacts</h2>
            <table className="styled-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {userContacts.map(contact => (
                        <tr key={contact.id}>
                            <td>{editingContactId === contact.id ? (
                                <input type="text" value={editedContact.name} onChange={(e) => setEditedContact({ ...editedContact, name: e.target.value })} />
                            ) : (
                                contact.name
                            )}</td>
                            <td>{editingContactId === contact.id ? (
                                <input type="email" value={editedContact.email} onChange={(e) => setEditedContact({ ...editedContact, email: e.target.value })} />
                            ) : (
                                contact.email
                            )}</td>
                            <td>{editingContactId === contact.id ? (
                                <input type="text" value={editedContact.contact} onChange={(e) => setEditedContact({ ...editedContact, contact: e.target.value })} />
                            ) : (
                                contact.contact
                            )}</td>
                            <td>
                                {editingContactId === contact.id ? (
                                    <button className="btn btn-edit" onClick={saveChanges}>Save</button>
                                ) : (
                                    <>
                                        <button className="btn btn-edit" onClick={() => enableEditingMode(contact.id, contact)}>Edit</button>
                                        <button className="btn btn-delete" onClick={() => deleteContact(contact.id)}>Delete</button>
                                    </>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default Home;*/


/*LAST WQALAY BG*/

import React, { useState, useEffect } from 'react';
import fireDb from "../firebase";
import { useAuth } from "../AuthContext";
import './Home.css';

const Home = () => {
    const { currentUser } = useAuth();
    const [userContacts, setUserContacts] = useState([]);
    const [editingContactId, setEditingContactId] = useState(null);
    const [editedContact, setEditedContact] = useState({ name: "", email: "", contact: "" });
    const [searchQuery, setSearchQuery] = useState("");

    useEffect(() => {
        if (currentUser) {
            const contactsRef = fireDb.child('contacts').orderByChild('userId').equalTo(currentUser.uid);
            contactsRef.on('value', (snapshot) => {
                const contacts = snapshot.val();
                const contactList = [];
                for (let id in contacts) {
                    contactList.push({ id, ...contacts[id] });
                }
                setUserContacts(contactList);
            });

            return () => contactsRef.off('value');
        }
    }, [currentUser]);

    const deleteContact = (id) => {
        if (window.confirm('Are you sure you want to delete this contact?')) {
            fireDb.child(`contacts/${id}`).remove()
                .then(() => {
                    setUserContacts(prevContacts => prevContacts.filter(contact => contact.id !== id));
                    console.log("Contact deleted successfully");
                })
                .catch(error => console.error("Error deleting contact:", error.message));
        }
    };

    const enableEditingMode = (id, contact) => {
        setEditingContactId(id);
        setEditedContact(contact);
    };

    const saveChanges = () => {
        fireDb.child(`contacts/${editingContactId}`).update(editedContact)
            .then(() => {
                console.log("Contact updated successfully");
                setEditingContactId(null);
            })
            .catch(error => console.error("Error updating contact:", error.message));
    };

    const handleContactChange = (e) => {
        const { value } = e.target;
        if (/^\d*$/.test(value)) {
            setEditedContact({ ...editedContact, contact: value });
        }
    };

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const filteredContacts = userContacts.filter(contact => 
        contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        contact.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        contact.contact.includes(searchQuery)
    );

    return (
        <div className="home-container">
            {!editingContactId && (
                <input 
                    type="text"
                    placeholder="Search contacts..."
                    value={searchQuery}
                    onChange={handleSearchChange}
                    className="search-bar"
                />
            )}
            {editingContactId ? (
                <div className="edit-container">
                    <input
                        type="text"
                        value={editedContact.name}
                        onChange={(e) => setEditedContact({ ...editedContact, name: e.target.value })}
                    />
                    <input
                        type="email"
                        value={editedContact.email}
                        onChange={(e) => setEditedContact({ ...editedContact, email: e.target.value })}
                    />
                    <input
                        type="text"
                        value={editedContact.contact}
                        onChange={handleContactChange}
                    />
                    <div className="button-container"> {}
                        <button className="btn btn-save" onClick={saveChanges}>Save</button>
                        <button className="btn btn-cancel" onClick={() => setEditingContactId(null)}>Cancel</button>
                    </div>
                </div>
            ) : (
                <table className="styled-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredContacts.map(contact => (
                            <tr key={contact.id}>
                                <td>{contact.name}</td>
                                <td>{contact.email}</td>
                                <td>{contact.contact}</td>
                                <td>
                                    <button className="btn btn-edit" onClick={() => enableEditingMode(contact.id, contact)}>Edit</button>
                                    <button className="btn btn-delete" onClick={() => deleteContact(contact.id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}

export default Home;
