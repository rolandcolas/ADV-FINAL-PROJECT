import React from 'react';
import './About.css'; 

const About = () => {
    return (
        <div className="about-container">
            <h2></h2>
            <div className="team-section">
                <div className="team-member">
                    <h3>Kent Josh - Lead JavaScript Developer</h3>
                    <p>Kent is our visionary leader in JavaScript development. With over a decade of experience, he's a master at turning complex ideas into elegant code solutions. npm install lambing</p>
                    <img src="https://chat.google.com/u/0/api/get_attachment_url?url_type=FIFE_URL&content_type=image%2Fjpeg&attachment_token=AOo0EEWq%2BBBxEDlDu0kNaAeU7yjV%2FoodBK0%2F2Xt4wDA%2Fcl%2FBezEns3ZOUOFNmt345Dp3C1Ldk4HrCsge%2F1M9ewX49XDTmTUbFtbxxVMCdC6zCDsL4g7J2LhLY5Boii2WkUw0VFEXqtwCXSBw5pJNbzcb8c8UOLafZp%2B4OgnaFM4DoR%2FBb3gVhCZryyDiPxiO2Nf6Xph7DToxeIaUauE5ou2JpZ1AqE7vEBTLAOYjPPEl3QBxiw12KxrxTqPo6gaaHKF%2BuJXfpokVPUv%2Fhs5bIB1ToISggg3AvkmUl7u78wkv9zefmxKqAw%2BLCz05Ea5a65wam0JnjAksc2F76%2Bgrbr4jOSnhZYJqsDZZKJF3gn8AMNUNaVEZtDLxTPNcmWGqmAZ6KQGV2TTr8QxsPa9gk1N65qHlu%2FCglEinqMjqMa1TmGncn9UjFeMMMcePu9qJEszlbJ8S0UktJo8QR1Sh2NiXQZyjFIoC75OCquf35dvGnmXWzqe5dx1wbNjjzvC8sHPpO4N2xgsB2cE5TKID11FplHUlbttVZgJ9oNZuKmTKcRnHv9ZoDkREw2Qpn0lx0oHYf7mIRSZXjeHNncAY%2BOw5B118&sz=w512" />
                </div>
                <div className="team-member">
                    <h3>Roland Colas - JavaScript Engineer</h3>
                    <p>Roland brings creativity and precision to our JavaScript projects. His attention to detail ensures that every line of code is optimized for performance and maintainability.tibo</p>
                    <img src="https://lh7-us.googleusercontent.com/7aeTrPtFC3iE11mMj_Fpqscd0a5HjTwIZ7yzPiEZnKx7DBYKW9Mb4BlKSS1lN5Br_EsrV_nOX9QtyCEOa_-RuaIzq76xSKLx7uzJS3M1Elm4FNlTwA8Ady_BoOt-IzCkonPJuiMoxQucZeqppl4xwn4" />
                </div>
                <div className="team-member">
                    <h3>Claire Heart Librea - Frontend Specialist</h3>
                    <p>Claire specializes in crafting immersive user experiences with JavaScript. Her expertise in frontend development enhances the usability and aesthetics of our applications.</p>
                    <img src="https://chat.google.com/u/0/api/get_attachment_url?url_type=FIFE_URL&content_type=image%2Fjpeg&attachment_token=AOo0EEXxVTaUe1u80RLUxLv%2BSotoD3emPB9Zp9ZmVj68PgQtdUeeWX0dedAbXYU%2FLUKXD3PRAwaFPOIvBtlgPRq8uz5qIUcPkIIVbbnm5X%2Fz34y2D%2FFKejY48JTXTi76zSB%2FrYV15kjcGyd0IQmTUzrRTkl24c0KIbWwKMIqHU95klWk3nN7VQHOo19AGmvkhEDvXKaTxSTM8uEH17iYvWTNTZq2kl3RjYN3jT8wjmUFnCsMDP6MliH4MtqPphXWvLyIrMFkdzUU4mvgqS%2FtN%2F2K8J3v8inHRPw%2FblezXfKJ37IH7rdGk1wMXwlXNlXWUKo9%2Fs0ic72t%2F5Q2WOiMemYDTBu8UMeG7iXs3YSbd4F%2FusWrFNldMfKzc2GtUONwTJaSVXk6sZhfT1HwmSYYmFDpKybUnJ3V6P0uOqqu3bZo4utqsZwS0AwANhwmDcx%2BfKEKyQ8kuClhPwwHP1yJaqZBp6uRkR%2Fx%2Bp78kC%2BAS1PNerLFEOQRB6wvHKj9OMNELunGhAPy6bnJMuEqFEFC9u0bgkDXpYq%2BHoUZhpHKcGirFRdV%2BJubV1JYoSJlKXHaPzLoGlAQr3%2F%2FSnK2zFrNd941VfoSig%3D%3D&sz=w512" />
                </div>
                <div className="team-member">
                    <h3>Carrell Butulan - JavaScript Tester and Debugger</h3>
                    <p>Carrell is our meticulous tester who ensures that our JavaScript applications are bug-free and reliable. His dedication to quality assurance guarantees smooth user experiences.</p>
                    <img src="https://chat.google.com/u/0/api/get_attachment_url?url_type=FIFE_URL&content_type=image%2Fjpeg&attachment_token=AOo0EEWV4qEsaZIJs6%2FzmNE1xSlEOzfwjR5P5IvJlE5E%2FY0WfUxGZN7YtcauS3pSpvsgfGEHSW2B%2BFOo%2BMn4%2FVjR%2F2lihgSNyjjXKB%2FqeXkYrZyITBwlw8CPabAVeEEx7xRdWe7oMbf%2FEX0xUBmyOX01RUSfaaGZ2HPyr3%2B0rZLzD0FIILDHfUQtpQc1jOK%2FwG%2F6WUGujKnxNLcSA6Cg2IzLziXAIO7phqjUKnaZpwXMGcdLvixIHt2%2F%2F1ypxMbYiQ0WCmgi5KUINCNGGLYi68e2BBGj27HMoiIZMacsxhlhbXvRShM0Ug2WKSAkj6Q%2FJ29aDNmoY5eYP%2BW11ye%2FSEcIpEC15s3XfKBy3W0bLJutA%2BvXUXojnAHh8zTpOyHjpDgxNDcHHZML6YG3yYdKjvavkVY5%2Bbq1JSfEoLPW2slP82cNUGz8bslhajaaSLkMRMnnq%2BELBIFY5bUrOfmtba%2BNFciSTpNqQWxJiACZI8beACDy8i%2Fqj9a02C7GRtkYqifM%2FDTqTPOt4aWvXWY6ASxUjAxliu8raiEssp1EQSwJw4yEpnyrk5OfAG5bCNavhZIwlgHycUfFqY65TD7pdK7abavcCw%3D%3D&sz=w512" />
                </div>
            </div>
        </div>
    );
};

export default About;
